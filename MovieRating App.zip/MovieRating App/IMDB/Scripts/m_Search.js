﻿//function aj(name, plot, image, year, tmdb) {
//    $.ajax({
//        method: 'get',
//        contenttype: 'json',
//        url: '/movies/create',
//        data: { name: name, image: image, year: year, plot: plot, tmdb_id: tmdb },
//        success: function (response) {
//            $("html").html(response);

//        },
//        error: function () {

//        }
//    });
//}

//function aj(name, plot, image, year, tmdb) {
//    $.ajax({
//        method: "post",
//        dataType: "json",
//        url: 'Intermediate',
//        data: { Name: name, Image: image, Year: year, Plot: plot, tmdb_id: tmdb },
//        success: function (response) {
//            alert("Is there a response");
//        },
//        error: function () {
//            alert("Is there a response");
//        }
//    });
//}
